public class UserRole {
	public int UserId { get; set; }

	public int RoleId { get; set; }

	public string Test { get; set; }
}