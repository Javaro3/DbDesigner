using Microsoft.EntityFrameworkCore;

public class TestDbContext : DbContext
{
	public virtual DbSet<User> Users { get; set; }

	public virtual DbSet<Role> Roles { get; set; }

	public virtual DbSet<Post> Posts { get; set; }

	public TestDbContext(DbContextOptions<TestDbContext> options) : base(options) {}
}