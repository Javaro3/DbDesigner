public class User {
	public int Id { get; set; }

	public string Name { get; set; }

	public ICollection<Role> Roles { get; set; } = new List<Role>();

	public ICollection<Post> Posts { get; set; } = new List<Post>();
}