INSERT INTO role (name) VALUES 
('Admin'), 
('User'), 
('Moderator'), 
('Editor'), 
('Viewer'), 
('Contributor'), 
('Subscriber'), 
('Manager'), 
('Developer'), 
('Designer'), 
('Analyst'), 
('Support');


INSERT INTO post (content, user_id) VALUES 
('This is the first post content.', 1), 
('Here is some interesting content for the second post.', 2), 
('Third post content goes here!', 3), 
('Enjoying the fourth post with some great insights.', 4), 
('Fifth post content is all about learning new things.', 5), 
('This is the sixth post, sharing some fun facts.', 6), 
('Seventh post content, let’s talk about technology.', 7), 
('Eighth post is all about travel adventures.', 8), 
('Ninth post content, discussing health and wellness.', 9), 
('Tenth post, sharing thoughts on personal development.', 10), 
('Eleventh post content, let’s explore creativity.', 11), 
('Finally, the twelfth post, reflecting on life experiences.', 12);


INSERT INTO user (name)
VALUES
('John Doe'),
('Jane Smith'),
('Alice Johnson'),
('Bob Brown'),
('Charlie Davis'),
('Emily White'),
('Frank Black'),
('Susan Green'),
('Michael Blue'),
('Linda Gray'),
('Brian Orange'),
('Jessica Purple');


INSERT INTO user_role (user_id, role_id) VALUES 
(1, 1), 
(2, 2), 
(3, 3), 
(4, 4), 
(5, 5), 
(6, 6), 
(7, 7), 
(8, 8), 
(9, 9), 
(10, 10), 
(11, 11), 
(12, 1