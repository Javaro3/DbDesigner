-- Database creating
CREATE DATABASE test;
GO

-- Using the database
USE test;
GO

-- Creating tables
CREATE TABLE user (
	id int IDENTITY(1, 1),
	name nvarchar(255) NOT NULL
);

CREATE TABLE role (
	id int IDENTITY(1, 1),
	name nvarchar(255) NOT NULL
);

CREATE TABLE user_role (
	user_id int NOT NULL,
	role_id int NOT NULL,
	test nchar(255) NOT NULL,
	CONSTRAINT FK_3aac787c FOREIGN KEY (user_id) REFERENCES user(id) ON DELETE CASCADE ON UPDATE CASCADE,
	CONSTRAINT FK_b79e6773 FOREIGN KEY (role_id) REFERENCES role(id) ON DELETE CASCADE ON UPDATE CASCADE
);

CREATE TABLE post (
	content nvarchar(255) NOT NULL,
	id int IDENTITY(1, 1) PRIMARY KEY,
	user_id int ,
	CONSTRAINT FK_1d9eb201 FOREIGN KEY (user_id) REFERENCES user(id) ON DELETE CASCADE ON UPDATE CASCADE
);

-- Creating indexes
CREATE CLUSTERED INDEX IDX_6a219355 ON user (id, name);

